"""Shared Lumen "Liquid Glass" GTK 3 design language. No resident process.

Same public helpers as Meridian, so existing Lumen applications keep working:
apply(), icon(), label(), button().
"""
import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gdk, GdkPixbuf

CSS = '''
/* Lumen Liquid Glass — deep glass surfaces, soft radii, electric accents. */
@define-color lg_bg #070b17;
@define-color lg_surface rgba(18, 26, 48, 0.72);
@define-color lg_surface_hi rgba(30, 42, 74, 0.78);
@define-color lg_text #e9f0ff;
@define-color lg_muted #93a2c4;
@define-color lg_blue #4c9dff;
@define-color lg_cyan #5be6ff;
@define-color lg_violet #8b7bff;

window, dialog, .background { background-color: @lg_bg; color: @lg_text; }
headerbar { background: rgba(14, 20, 38, 0.86); border-bottom: 1px solid rgba(150, 180, 255, 0.10); box-shadow: none; min-height: 40px; }
headerbar .title { color: @lg_text; font-weight: 600; }

button { background-image: none; background-color: rgba(31, 44, 76, 0.62); border: 1px solid rgba(150, 180, 255, 0.15); border-radius: 13px; color: #e3ecff; box-shadow: none; padding: 9px 16px; transition: background-color 140ms ease, border-color 140ms ease; }
button:hover { background-color: rgba(52, 78, 132, 0.70); border-color: rgba(91, 230, 255, 0.42); }
button:active { background-color: rgba(64, 96, 158, 0.78); }
button:disabled { color: #6b7a99; background-color: rgba(20, 27, 46, 0.55); border-color: rgba(120, 145, 190, 0.10); }
button.suggested-action { background-image: linear-gradient(135deg, #3f8bff, #6f6bff); color: #f6faff; border-color: rgba(150, 205, 255, 0.55); font-weight: 600; }
button.suggested-action:hover { background-image: linear-gradient(135deg, #57a0ff, #837dff); }
button.suggested-action:disabled { background-image: none; background-color: rgba(30, 40, 70, 0.6); color: #7585a6; border-color: rgba(120, 145, 190, 0.12); }
button.destructive-action { background: rgba(120, 40, 66, 0.65); border-color: rgba(255, 120, 160, 0.35); color: #ffe6ee; }
button.flat, .nav, .category { background: transparent; border-color: transparent; box-shadow: none; }
.nav:checked, .category:checked { background: rgba(76, 157, 255, 0.18); border-color: rgba(91, 230, 255, 0.35); color: #bfefff; }

entry, searchentry, combobox entry { background: rgba(10, 16, 32, 0.72); color: #edf5ff; border: 1px solid rgba(140, 170, 230, 0.20); border-radius: 14px; padding: 10px 14px; caret-color: @lg_cyan; }
entry:focus, searchentry:focus { border-color: rgba(91, 230, 255, 0.62); box-shadow: 0 0 0 3px rgba(76, 157, 255, 0.12); }

.title, .heading { font-size: 28px; font-weight: 600; letter-spacing: -0.5px; color: #f2f8ff; }
.brand { font-size: 20px; font-weight: 700; letter-spacing: 4px; color: #bfe9ff; }
.subtitle, .muted, .dim { color: @lg_muted; font-size: 12px; }
.eyebrow { color: @lg_cyan; font-size: 10px; font-weight: 700; letter-spacing: 2.4px; }
.hero { background-image: linear-gradient(120deg, rgba(38, 70, 130, 0.55), rgba(62, 44, 110, 0.42)); border: 1px solid rgba(120, 165, 255, 0.22); border-radius: 22px; padding: 26px; }
.hero .title { font-size: 34px; }

.sidebar, .rail { background: rgba(11, 17, 33, 0.72); border-right: 1px solid rgba(140, 170, 230, 0.10); padding: 18px 12px; }
.sidebar button { padding: 5px 12px; min-height: 18px; }
.card, .section, .appcard { background: rgba(20, 29, 53, 0.62); border: 1px solid rgba(150, 180, 255, 0.13); border-radius: 18px; padding: 18px; box-shadow: 0 10px 34px rgba(2, 6, 16, 0.35); background-image: none; }
.appcard:hover { background: rgba(34, 50, 86, 0.72); border-color: rgba(91, 230, 255, 0.38); }
.glass { background: rgba(20, 29, 53, 0.66); border: 1px solid rgba(160, 190, 255, 0.16); border-radius: 22px; box-shadow: 0 18px 48px rgba(2, 6, 16, 0.45); }

separator { background: rgba(140, 170, 230, 0.14); min-height: 1px; }
scrolledwindow, viewport, flowbox, list, listbox { background: transparent; }
notebook, notebook stack, notebook header, .view, treeview { background-color: transparent; color: #dbe8ff; }
row { background: transparent; border-bottom: 1px solid rgba(140, 170, 230, 0.08); padding: 9px; }
row:selected { background: rgba(76, 157, 255, 0.16); }

progressbar trough { background: rgba(10, 16, 32, 0.75); border-radius: 6px; min-height: 7px; }
progressbar progress { background-image: linear-gradient(90deg, #4c9dff, #5be6ff); border-radius: 6px; min-height: 7px; }
textview text { background: rgba(8, 13, 27, 0.82); color: #cfe0f8; }
menubar, menu { background: rgba(14, 21, 40, 0.96); color: #e2ecff; padding: 6px; border: 1px solid rgba(150, 180, 255, 0.16); border-radius: 12px; }
menuitem { padding: 7px 12px; border-radius: 8px; }
menuitem:hover { background: rgba(76, 157, 255, 0.18); }
checkbutton, radiobutton { padding: 5px; }
tooltip { background: rgba(12, 18, 36, 0.96); color: #e6eeff; border: 1px solid rgba(150, 180, 255, 0.18); border-radius: 10px; }
'''


def apply():
    p = Gtk.CssProvider()
    p.load_from_data(CSS.encode())
    Gtk.StyleContext.add_provider_for_screen(Gdk.Screen.get_default(), p, 700)
    return False


def icon(name, size=22):
    return Gtk.Image.new_from_icon_name('lumen-' + name + '-symbolic', Gtk.IconSize.BUTTON) if size == 22 else Gtk.Image.new_from_pixbuf(GdkPixbuf.Pixbuf.new_from_file_at_scale('/usr/share/icons/hicolor/scalable/apps/lumen.svg', size, size, True))


def label(text, cls=None):
    w = Gtk.Label(label=text, xalign=0)
    w.set_line_wrap(True)
    if cls:
        w.get_style_context().add_class(cls)
    return w


def button(text, callback=None, kind=None):
    b = Gtk.Button(label=text)
    if callback:
        b.connect('clicked', callback)
    if kind:
        b.get_style_context().add_class(kind)
    return b
