"""Read genuine Flatpak AppStream metadata into a small indexed catalogue."""
from pathlib import Path
import sqlite3,gzip,xml.etree.ElementTree as ET,os,re
FIELDS='id,name,summary,description,icon,screenshot,ref,categories,developer'
def selected_language():
 s=os.environ.get('LANGUAGE') or os.environ.get('LC_ALL') or os.environ.get('LC_MESSAGES') or os.environ.get('LANG','en')
 return s.split(':')[0].split('.')[0].split('_')[0] or 'en'
def clean(s):return ''.join(c for c in s if not (0x1f000<=ord(c)<=0x1ffff or 0x2600<=ord(c)<=0x27bf or ord(c) in (0xfe0f,0x200d)))
def build(source,target):
 source=Path(source);target=Path(target);target.parent.mkdir(parents=True,exist_ok=True)
 tmp=target.with_suffix('.building');tmp.unlink(missing_ok=True)
 db=sqlite3.connect(tmp);db.execute('create table locale(language text)');db.execute('insert into locale values (?)',(selected_language(),));db.execute('create table apps(id text primary key,name text,summary text,description text,icon text,screenshot text,ref text,categories text,developer text)')
 root=source.parent
 iconmap={p.name:str(p) for p in root.glob('icons/128x128/*')};iconmap.update({p.name:str(p) for p in root.glob('icons/64x64/*') if p.name not in iconmap})
 opener=gzip.open if source.suffix=='.gz' else open
 count=0
 with opener(source,'rb') as f:
  for _,e in ET.iterparse(f,events=('end',)):
   if e.tag!='component':continue
   bundle=next((b.text for b in e.findall('bundle') if b.get('type')=='flatpak'),None)
   if not bundle or not bundle.startswith('app/'):e.clear();continue
   parts=bundle.split('/');appid=parts[1]
   def txt(tag):
    choices=e.findall(tag);lang=selected_language();x=next((x for x in choices if x.get('{http://www.w3.org/XML/1998/namespace}lang','').split('_')[0].split('-')[0]==lang),None)
    if x is None:x=next((x for x in choices if not x.get('{http://www.w3.org/XML/1998/namespace}lang')),None)
    return clean(' '.join(x.itertext()).strip()) if x is not None else ''
   image=''
   for im in e.findall('icon'):
    v=(im.text or '').strip()
    if im.get('type')=='cached' and v in iconmap:image=iconmap[v];break
    if im.get('type')=='remote' and v.startswith('https://'):image=v
   screen=e.find("screenshots/screenshot[@type='default']/image[@type='source']")
   if screen is None:screen=e.find('screenshots/screenshot/image')
   shot=screen.text.strip() if screen is not None and screen.text else ''
   if not shot.startswith('https://'):shot=''
   desc=txt('description');name=txt('name') or appid
   row=(appid,name,txt('summary'),desc[:16000],image,shot,bundle,','.join(x.text for x in e.findall('categories/category') if x.text),txt('developer_name') or txt('developer/name'))
   db.execute('insert or replace into apps values (?,?,?,?,?,?,?,?,?)',row);count+=1;e.clear()
 db.execute('create index names on apps(name)');db.commit();db.close();os.replace(tmp,target);return count
class Catalog:
 def __init__(self,path):
  db=sqlite3.connect('file:'+str(path)+'?mode=ro',uri=True)
  try:language=db.execute('select language from locale').fetchone()[0]
  except sqlite3.OperationalError:language='en'
  if language!=selected_language():
   db.close();path=Path.home()/'.cache/lumen-store'/('catalog-'+selected_language()+'.sqlite')
   if not path.exists():build(appstream(),path)
   db=sqlite3.connect('file:'+str(path)+'?mode=ro',uri=True)
  self.path=path;self.db=db;self.db.row_factory=sqlite3.Row
 def get(self,appid):
  r=self.db.execute('select * from apps where id=?',(appid,)).fetchone();return dict(r) if r else None
 def search(self,text='',category='',limit=36):
  q='%'+text+'%';c='%'+category+'%'
  return [dict(r) for r in self.db.execute('select * from apps where (name like ? or summary like ? or id like ?) and categories like ? order by name limit ?',(q,q,q,c,limit))]
 def count(self):return self.db.execute('select count(*) from apps').fetchone()[0]
def appstream():
 p=Path('/var/lib/flatpak/appstream/flathub/x86_64/active/appstream.xml.gz')
 if p.exists():return p
 p=Path.home()/'.local/share/flatpak/appstream/flathub/x86_64/active/appstream.xml.gz'
 if p.exists():return p
 raise FileNotFoundError('No signed Flathub AppStream catalog is available. Refresh the catalog when online.')
if __name__=='__main__':
 import sys
 print(build(sys.argv[1],sys.argv[2]))
