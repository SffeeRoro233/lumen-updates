#!/usr/bin/python3
"""V1.1 package configuration. Only language, cursor defaults and version metadata."""
import pathlib,subprocess,configparser,xml.etree.ElementTree as ET,os,re,json
R=pathlib.Path('/')
if not (R/'usr/share/lumen/image-id').exists():raise SystemExit('Not a Lumen installation')
def ini(path,section,values):
 p=R/path;p.parent.mkdir(parents=True,exist_ok=True);c=configparser.ConfigParser(interpolation=None);c.optionxform=str
 if p.exists():c.read(p)
 if section not in c:c.add_section(section)
 for k,v in values.items():c[section][k]=str(v)
 with p.open('w') as f:c.write(f,space_around_delimiters=False)
def write(path,text):p=R/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
def xml(path):
 p=R/path;p.parent.mkdir(parents=True,exist_ok=True)
 tree=ET.parse(p) if p.exists() else ET.ElementTree(ET.Element('channel',name='xsettings',version='1.0'));root=tree.getroot();g=root.find("property[@name='Gtk']")
 if g is None:g=ET.SubElement(root,'property',name='Gtk',type='empty')
 for key,typ,val in [('CursorThemeName','string','default'),('CursorThemeSize','int','32')]:
  n=g.find("property[@name='"+key+"']")
  if n is None:n=ET.SubElement(g,'property',name=key,type=typ)
  n.set('value',val)
 tree.write(p,encoding='unicode')
# 'default' must INHERIT an actual theme. Linking default/index.theme to a
# standalone theme with no Inherits and no default/cursors causes fallback.
p=R/'usr/share/icons/default/index.theme';target=''
if p.exists():
 resolved=p.resolve();candidate=resolved.parent.name
 if (resolved.parent/'cursors').is_dir():target=candidate
 else:
  c=configparser.ConfigParser();c.read(p)
  for name in c.get('Icon Theme','Inherits',fallback='').split(','):
   if name and (R/'usr/share/icons'/name/'cursors').is_dir():target=name;break
if not target:
 for name in ['Lumen-V1','Adwaita']:
  if (R/'usr/share/icons'/name/'cursors').is_dir():target=name;break
if not target:raise SystemExit('Existing cursor artwork not found; refusing to substitute an unknown theme.')
write('usr/share/icons/Lumen-System-Default/default.theme','[Icon Theme]\nName=Default\nName[fr]=Par défaut\nComment=Existing Lumen system cursor, correctly inherited\nInherits='+target+'\n')
subprocess.run(['update-alternatives','--install','/usr/share/icons/default/index.theme','x-cursor-theme','/usr/share/icons/Lumen-System-Default/default.theme','130'],check=True)
subprocess.run(['update-alternatives','--set','x-cursor-theme','/usr/share/icons/Lumen-System-Default/default.theme'],check=True)
for home in ['etc/skel']:
 ini(home+'/.config/gtk-3.0/settings.ini','Settings',{'gtk-cursor-theme-name':'default','gtk-cursor-theme-size':32});xml(home+'/.config/xfce4/xfconf/xfce-perchannel-xml/xsettings.xml')
 for name,starts,extra in [('.Xresources',('Xcursor.theme:','Xcursor.size:'),'Xcursor.theme: default\nXcursor.size: 32\n'),('.gtkrc-2.0',('gtk-cursor-theme-name','gtk-cursor-theme-size'),'gtk-cursor-theme-name="default"\ngtk-cursor-theme-size=32\n')]:
  p=R/home/name;lines=p.read_text().splitlines() if p.exists() else [];p.write_text('\n'.join(s for s in lines if not s.strip().startswith(starts))+'\n'+extra)
xml('etc/xdg/xfce4/xfconf/xfce-perchannel-xml/xsettings.xml')
ini('etc/gtk-3.0/settings.ini','Settings',{'gtk-cursor-theme-name':'default','gtk-cursor-theme-size':32})
ini('etc/lightdm/lightdm-gtk-greeter.conf','greeter',{'cursor-theme-name':'default','cursor-theme-size':32})
p=R/'etc/gtk-2.0/gtkrc';lines=p.read_text().splitlines() if p.exists() else [];write('etc/gtk-2.0/gtkrc','\n'.join(s for s in lines if not s.strip().startswith(('gtk-cursor-theme-name','gtk-cursor-theme-size')))+'\ngtk-cursor-theme-name="default"\ngtk-cursor-theme-size=32\n')
write('etc/X11/Xresources/90-lumen-cursor','Xcursor.theme: default\nXcursor.size: 32\n')
write('etc/profile.d/90-lumen-cursor.sh',': "${XCURSOR_THEME:=default}"\n: "${XCURSOR_SIZE:=32}"\nexport XCURSOR_THEME XCURSOR_SIZE\n')
p=R/'etc/environment';lines=p.read_text().splitlines() if p.exists() else [];p.write_text('\n'.join(s for s in lines if not s.strip().startswith(('XCURSOR_THEME=','XCURSOR_SIZE=')))+'\nXCURSOR_THEME=default\nXCURSOR_SIZE=32\n')
write('usr/share/glib-2.0/schemas/99-lumen-v1.gschema.override',"[org.gnome.desktop.interface]\ncursor-theme='default'\ncursor-size=32\n")
subprocess.run(['glib-compile-schemas','--strict','/usr/share/glib-2.0/schemas'],check=True)
# Generate both requested locales, preserving every previously enabled locale.
p=R/'etc/locale.gen';t=p.read_text()
for loc in ['fr_FR.UTF-8','en_US.UTF-8']:
 line=loc+' UTF-8'
 if not re.search(r'^'+re.escape(line)+r'\s*$',t,re.M):t+='\n'+line+'\n'
p.write_text(t);subprocess.run(['locale-gen'],check=True)
# Add rather than replace existing Flatpak language restrictions. No app update
# or uninstall is run here. Runtime translations arrive via normal Flatpak updates.
r=subprocess.run(['flatpak','config','--system','--get','languages'],capture_output=True,text=True)
if r.returncode==0 and r.stdout.strip() not in ('','*','all','*unset*'):
 langs=set(r.stdout.strip().split(';'))|{'fr','en'};subprocess.run(['flatpak','config','--system','--set','languages',';'.join(sorted(langs))],check=True)
r=subprocess.run(['flatpak','config','--system','--get','extra-languages'],capture_output=True,text=True)
if r.returncode==0 and r.stdout.strip() not in ('*','all'):
 langs=(set(filter(None,r.stdout.strip().split(';')))-{'*unset*'})|{'fr','en'};subprocess.run(['flatpak','config','--system','--set','extra-languages',';'.join(sorted(langs))],check=True)
# Version belongs to this Lumen release, not the Debian package base version.
p=R/'etc/os-release';t=p.read_text()
for key,value in [('PRETTY_NAME','Lumen V1.1 (Debian 13)'),('NAME','Lumen OS'),('VERSION_ID','1.1'),('VERSION','1.1')]:
 t=re.sub(r'^'+key+r'=.*$',key+'='+json.dumps(value),t,flags=re.M)
p.write_text(t)
for name in ['etc/issue','etc/lumen-installed']:
 p=R/name
 if p.exists():p.write_text(re.sub(r'Lumen OS (?:0\.4|1\.0)', 'Lumen OS 1.1',p.read_text()))
# Localize only existing Lumen desktop entries; commands/icons are untouched.
names={'lumen-control':'Paramètres Lumen','lumen-launcher':'Applications Lumen','lumen-personalize':'Personnaliser Lumen','lumen-network':'Internet','lumen-login-settings':'Connexion et sécurité','lumen-store':'Lumen Store','lumen-install':'Installer Lumen','lumen-files':'Fichiers','lumen-focus':'Concentration Lumen','lumen-notes':'Notes Lumen','lumen-palette':'Palette de commandes Lumen','lumen-wine':'Application Windows (Wine)'}
for name,title in names.items():
 p=R/'usr/share/applications'/(name+'.desktop')
 if p.exists():
  lines=[s for s in p.read_text().splitlines() if not s.startswith('Name[fr]=')];p.write_text('\n'.join(lines)+'\nName[fr]='+title+'\n')
subprocess.run(['update-desktop-database','/usr/share/applications'],check=True)
print('LUMEN_V11_CONFIGURED: language, default cursor, signed updater/version only. Sign out or restart to apply session changes.')

state=R/'var/lib/lumen-updater';state.mkdir(parents=True,exist_ok=True);pending=state/'release-installed.json.tmp';pending.write_text(json.dumps({'version':'1.1','configured':True})+'\n');pending.chmod(0o644);pending.replace(state/'release-installed.json')
