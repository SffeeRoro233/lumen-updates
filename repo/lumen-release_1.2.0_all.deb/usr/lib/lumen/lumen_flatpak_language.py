"""Fetch new locale subpaths at the already installed commit, without upgrading apps."""
def ensure_translations():
 import gi
 gi.require_version('Flatpak','1.0')
 from gi.repository import Flatpak
 results=[]
 for installation in [Flatpak.Installation.new_user(),Flatpak.Installation.new_system(None)]:
  refs=installation.list_installed_refs(None);work=[]
  for ref in refs:
   if ref.get_kind()!=Flatpak.RefKind.RUNTIME or not ref.get_name().endswith('.Locale'):continue
   paths=ref.get_subpaths()
   # No partial checkout means the whole locale extension is already present.
   if not paths:continue
   wanted=sorted(set(paths)|{'/fr','/en'})
   if set(wanted)!=set(paths):work.append((ref.format_ref(),wanted,ref.get_commit()))
  if not work:continue
  transaction=Flatpak.Transaction.new_for_installation(installation,None)
  transaction.set_disable_related(True);transaction.set_disable_dependencies(True)
  for ref,paths,commit in work:transaction.add_update(ref,paths,commit)
  transaction.connect('ready',lambda *_:True);transaction.run(None)
  results.extend(ref for ref,_,_ in work)
 return results
