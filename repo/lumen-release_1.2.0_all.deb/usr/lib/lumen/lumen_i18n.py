"""Native gettext presentation only. No translation of commands or stored user data."""
import gettext,re
_trans=gettext.translation('lumen',localedir='/usr/share/locale',fallback=True)
def translate(text):
 if not isinstance(text,str):return text
 out=_trans.gettext(text)
 if out!=text:return out
 if '<' in text and '>' in text:
  return re.sub(r'>([^<>]+)<',lambda m:'>'+_trans.gettext(m.group(1))+'<',text)
 return text
