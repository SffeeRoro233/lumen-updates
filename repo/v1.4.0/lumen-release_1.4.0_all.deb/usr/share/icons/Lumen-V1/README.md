Lumen V1 — original native Xcursor theme.
Slim white artwork, a dark hairline for light surfaces and restrained cyan accents.
16/22/24/32/48/64 px; default 24 px, artwork at 72 % of the box. Busy/progress: 24 frames, 40 ms each.
All aliases resolve to bundled original artwork, with no default XFCE or Adwaita inheritance.
Only native cursor animation; no daemon, timer service or compositor effect.
Unsupported animated-cursor clients can display the first frame.
