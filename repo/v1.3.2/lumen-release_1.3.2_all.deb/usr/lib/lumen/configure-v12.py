#!/usr/bin/python3
"""V1.2 package configuration: version metadata and system-wide desktop files.

Per-user files are migrated at login by migrate-v12-session, with backups.
"""
import json
import pathlib
import subprocess

R = pathlib.Path('/')
if not (R / 'usr/share/lumen/image-id').exists():
    raise SystemExit('Not a Lumen installation')

# Never clobber newer metadata: the package ships its own release.json and a
# later release must not be rewritten as 1.2 (that made the updater offer an
# already-installed version forever).
meta_path = R / 'usr/share/lumen/release.json'
meta = {'version': '1.2', 'package_version': '1.2.0', 'debian': '13'}
try:
    shipped = json.loads(meta_path.read_text())
    if isinstance(shipped, dict) and shipped.get('package_version'):
        meta = shipped
except (OSError, ValueError):
    meta_path.write_text(json.dumps(meta) + '\n')
version = str(meta.get('version', '1.2'))
installed = str(meta.get('package_version', '1.2.0'))
state = R / 'var/lib/lumen-updater'
state.mkdir(parents=True, exist_ok=True)
pending = state / 'release-installed.json.tmp'
pending.write_text(json.dumps({'version': installed, 'release': version, 'configured': True}) + '\n')
pending.chmod(0o644)
pending.replace(state / 'release-installed.json')

# Desktop database so the new Applications entry appears in every menu.
subprocess.run(['update-desktop-database', '/usr/share/applications'], check=False)
# The GTK theme is a plain file change; no service restart is required.
print('LUMEN_V12_CONFIGURED: Liquid Glass interface, Spotlight search, simplified updates. Files and applications preserved.')
