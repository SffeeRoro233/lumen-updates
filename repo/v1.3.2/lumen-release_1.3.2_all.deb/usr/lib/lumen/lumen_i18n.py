"""Native gettext presentation only. No translation of commands or stored user data."""
import gettext, re

# A single unreadable catalogue must never stop a Lumen application from
# starting.  Before 1.2.3 a corrupt /usr/share/locale/fr/LC_MESSAGES/lumen.mo
# raised OSError at import time and every GTK entry point died silently;
# the desktop then looked "dead" with no window and no message.
try:
    _trans = gettext.translation('lumen', localedir='/usr/share/locale', fallback=True)
    _trans.gettext('Theme')
except (OSError, ValueError, EOFError, UnicodeError):
    _trans = gettext.NullTranslations()


def translate(text):
    if not isinstance(text, str):
        return text
    try:
        out = _trans.gettext(text)
    except Exception:
        return text
    if out != text:
        return out
    if '<' in text and '>' in text:
        return re.sub(r'>([^<>]+)<', lambda m: '>' + _trans.gettext(m.group(1)) + '<', text)
    return text
