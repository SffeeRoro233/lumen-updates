#!/usr/bin/python3
"""Resolve the newest signed Lumen release directory.

Why this exists: the APT index used to live at one fixed URL (repo/Packages).
A static host may keep serving an old copy of that URL, so a client could see
an outdated package list.  The fix is that every release gets its own immutable
directory (repo/v1.2.0/, repo/v1.3.0/, ...), and a small signed pointer file
says which directory is current.  Because the index URL itself changes with
every release, a cached copy can never hide a newer release.

Properties enforced here:
  * HTTPS only, exact expected host/owner prefix (no redirect to elsewhere);
  * the pointer is signed by the Lumen key and verified with gpgv;
  * the version may never go backwards compared with what is installed;
  * on any doubt the caller keeps its existing, already-working source.
"""
import json
import pathlib
import re
import subprocess
import tempfile
import urllib.parse
import urllib.request

MANIFEST_URL = 'https://raw.githubusercontent.com/SffeeRoro233/lumen-updates/main/release.json'
SIGNATURE_URL = MANIFEST_URL + '.sig'
ALLOWED_PREFIX = 'https://raw.githubusercontent.com/SffeeRoro233/lumen-updates/main/repo/'
KEYRING = '/usr/share/keyrings/lumen-updates.gpg'
SOURCE = pathlib.Path('/etc/apt/sources.list.d/lumen-updates.list')
INSTALLED = pathlib.Path('/var/lib/lumen-updater/release-installed.json')
MAX_BYTES = 8192


def _version(text):
    return tuple(int(n) for n in re.findall(r'\d+', str(text))[:4])


def installed_version():
    try:
        return json.loads(INSTALLED.read_text()).get('version', '0')
    except (OSError, ValueError):
        return '0'


def fetch(url, timeout=20):
    """Fetch a small file over HTTPS with a cache-busting query string."""
    parts = urllib.parse.urlsplit(url)
    if parts.scheme != 'https' or parts.hostname != 'raw.githubusercontent.com':
        raise ValueError('Unexpected release pointer host.')
    busted = url + ('&' if '?' in url else '?') + 't=' + str(int(__import__('time').time()))
    request = urllib.request.Request(busted, headers={
        'Cache-Control': 'no-cache', 'Pragma': 'no-cache',
        'User-Agent': 'Lumen-Release-Resolver/1'})
    with urllib.request.urlopen(request, timeout=timeout) as response:
        if urllib.parse.urlsplit(response.url).hostname != 'raw.githubusercontent.com':
            raise ValueError('Release pointer redirected elsewhere.')
        data = response.read(MAX_BYTES + 1)
    if len(data) > MAX_BYTES:
        raise ValueError('Release pointer is too large.')
    return data


def verify(manifest_bytes, signature_bytes, keyring=None):
    """Verify a detached signature with the installed public key only."""
    keyring = keyring or KEYRING
    with tempfile.TemporaryDirectory() as work:
        work = pathlib.Path(work)
        data = work / 'release.json'
        signature = work / 'release.json.sig'
        data.write_bytes(manifest_bytes)
        signature.write_bytes(signature_bytes)
        result = subprocess.run(
            ['gpgv', '--keyring', keyring, '--status-fd', '1',
             str(signature), str(data)],
            capture_output=True, text=True, timeout=20)
        if result.returncode != 0:
            raise ValueError('Release pointer signature is not valid.')
        if 'VALIDSIG EDEF2384E284EE81BA30859935FF6549F7CAE0C4' not in result.stdout:
            raise ValueError('Release pointer is signed by an unknown key.')
    return True


def parse(manifest_bytes, signature_bytes=None, keyring=None):
    """Return a validated manifest dictionary. Raises on anything suspicious."""
    keyring = keyring or KEYRING
    if signature_bytes is not None:
        verify(manifest_bytes, signature_bytes, keyring)
    data = json.loads(manifest_bytes)
    if not isinstance(data, dict):
        raise ValueError('Invalid release pointer.')
    version = data.get('version')
    directory = data.get('repo')
    if not isinstance(version, str) or not re.fullmatch(r'\d+(\.\d+){1,3}', version):
        raise ValueError('Invalid version in release pointer.')
    if not isinstance(directory, str) or not directory.startswith(ALLOWED_PREFIX):
        raise ValueError('Release pointer points outside the Lumen repository.')
    if not directory.endswith('/') or '..' in directory or ' ' in directory:
        raise ValueError('Invalid release directory.')
    return {'version': version, 'repo': directory}


def choose(manifest, installed=None):
    """Return (version, repo_dir) only when it is a real, non-downgrade change."""
    installed = installed if installed is not None else installed_version()
    if _version(manifest['version']) < _version(installed):
        raise ValueError('Release pointer is older than the installed version.')
    return manifest['version'], manifest['repo']


def current_source():
    try:
        return SOURCE.read_text().strip()
    except OSError:
        return ''


def source_line(directory, keyring='/usr/share/keyrings/lumen-updates.gpg'):
    return 'deb [arch=amd64 signed-by=' + keyring + '] ' + directory + ' ./'


def update_source(directory):
    """Atomically point APT at the resolved directory. Returns True if changed."""
    line = source_line(directory)
    if current_source() == line:
        return False
    SOURCE.parent.mkdir(parents=True, exist_ok=True)
    pending = SOURCE.with_suffix('.list.lumen-new')
    pending.write_text(line + '\n')
    pending.chmod(0o644)
    pending.replace(SOURCE)
    return True


def resolve():
    """Full resolution: fetch, verify, refuse downgrade, rewrite the source."""
    manifest = parse(fetch(MANIFEST_URL), fetch(SIGNATURE_URL))
    version, directory = choose(manifest)
    changed = update_source(directory)
    return {'version': version, 'repo': directory, 'changed': changed}


if __name__ == '__main__':
    print(json.dumps(resolve(), indent=2))
