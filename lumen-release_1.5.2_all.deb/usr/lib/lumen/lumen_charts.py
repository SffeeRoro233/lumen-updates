"""Lightweight Cairo charts for the Lumen tools.

Deliberately minimal: a ring buffer plus polylines. No animation loop of its
own — the parent window refreshes on a timer, so a hidden window costs nothing.
When the user asked for reduced or no animations, the charts simply repaint
without easing.
"""
import collections

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk  # noqa: E402

import cairo  # noqa: E402


class Spark(Gtk.DrawingArea):
    """History curve with a soft fill. Values are real, never smoothed away."""

    def __init__(self, length=90, color=(0.30, 0.62, 1.0), ceiling=100.0, height=64):
        super().__init__()
        self.values = collections.deque([0.0] * length, maxlen=length)
        self.color = color
        self.ceiling = ceiling
        self.set_size_request(-1, height)
        self.connect('draw', self._draw)

    def push(self, value):
        self.values.append(max(min(float(value), self.ceiling), 0.0))
        self.queue_draw()

    def _draw(self, widget, ctx):
        width = widget.get_allocated_width()
        height = widget.get_allocated_height()
        ctx.set_source_rgba(1, 1, 1, 0.03)
        ctx.rectangle(0, 0, width, height)
        ctx.fill()

        points = list(self.values)
        if len(points) < 2 or width < 4:
            return
        step = width / float(len(points) - 1)

        def y_of(value):
            return height - (value / self.ceiling) * (height - 6) - 3

        ctx.new_path()
        ctx.move_to(0, height)
        for index, value in enumerate(points):
            ctx.line_to(index * step, y_of(value))
        ctx.line_to(width, height)
        ctx.close_path()
        gradient = cairo.LinearGradient(0, 0, 0, height)
        gradient.add_color_stop_rgba(0, self.color[0], self.color[1], self.color[2], 0.34)
        gradient.add_color_stop_rgba(1, self.color[0], self.color[1], self.color[2], 0.02)
        ctx.set_source(gradient)
        ctx.fill()

        ctx.set_line_width(1.6)
        ctx.set_source_rgba(self.color[0], self.color[1], self.color[2], 0.95)
        ctx.new_path()
        for index, value in enumerate(points):
            if index == 0:
                ctx.move_to(0, y_of(value))
            else:
                ctx.line_to(index * step, y_of(value))
        ctx.stroke()


class CoreBars(Gtk.DrawingArea):
    """One bar per logical core: instant, honest, cheap."""

    def __init__(self, height=54):
        super().__init__()
        self.values = []
        self.set_size_request(-1, height)
        self.connect('draw', self._draw)

    def set_values(self, values):
        self.values = list(values)
        self.queue_draw()

    def _draw(self, widget, ctx):
        width = widget.get_allocated_width()
        height = widget.get_allocated_height()
        if not self.values:
            return
        count = len(self.values)
        gap = 3
        bar = max((width - gap * (count - 1)) / float(count), 2)
        for index, value in enumerate(self.values):
            x = index * (bar + gap)
            ratio = max(min(value / 100.0, 1.0), 0.0)
            ctx.set_source_rgba(1, 1, 1, 0.05)
            ctx.rectangle(x, 0, bar, height)
            ctx.fill()
            ctx.set_source_rgba(0.36, 0.70, 1.0, 0.85)
            ctx.rectangle(x, height * (1 - ratio), bar, height * ratio)
            ctx.fill()
