"""Lumen system data layer — real readings only, no invented values.

Every figure comes from /proc, /sys or a documented command. When a source is
missing the caller gets None (or an empty list) and must display "unavailable"
instead of a fake number.

No third-party dependency: standard library only, so the tools stay light and
start instantly.
"""
import glob
import json
import os
import pathlib
import shutil
import subprocess
import time

CLK_TCK = os.sysconf('SC_CLK_TCK')
PAGE = os.sysconf('SC_PAGE_SIZE')


def _read(path, default=None):
    try:
        return pathlib.Path(path).read_text()
    except OSError:
        return default


def _int(value, default=0):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def cpu_times():
    line = (_read('/proc/stat', '') or '').splitlines()[0]
    parts = [_int(p) for p in line.split()[1:]]
    idle = parts[3] + (parts[4] if len(parts) > 4 else 0)
    total = sum(parts)
    return total, idle


def per_core_times():
    cores = []
    for line in (_read('/proc/stat', '') or '').splitlines():
        if not line.startswith('cpu') or line[3] == ' ':
            continue
        parts = [_int(p) for p in line.split()[1:]]
        idle = parts[3] + (parts[4] if len(parts) > 4 else 0)
        cores.append((sum(parts), idle))
    return cores


def cpu_model():
    for line in (_read('/proc/cpuinfo', '') or '').splitlines():
        if line.lower().startswith('model name'):
            return line.split(':', 1)[1].strip()
    return None


def cpu_count():
    return os.cpu_count() or 1


def meminfo():
    data = {}
    for line in (_read('/proc/meminfo', '') or '').splitlines():
        key, _, rest = line.partition(':')
        data[key] = _int(rest.strip().split()[0]) * 1024 if rest.strip() else 0
    total = data.get('MemTotal', 0)
    available = data.get('MemAvailable', 0)
    used = max(total - available, 0) if total else 0
    return {
        'total': total,
        'available': available,
        'used': used,
        'cached': data.get('Cached', 0) + data.get('SReclaimable', 0),
        'buffers': data.get('Buffers', 0),
        'percent': round(used * 100.0 / total, 1) if total else None,
        'swap_total': data.get('SwapTotal', 0),
        'swap_used': max(data.get('SwapTotal', 0) - data.get('SwapFree', 0), 0),
    }


def loadavg():
    parts = (_read('/proc/loadavg', '') or '').split()
    if len(parts) < 3:
        return None
    return {'1': float(parts[0]), '5': float(parts[1]), '15': float(parts[2])}


def uptime():
    return float((_read('/proc/uptime', '0') or '0').split()[0] or 0)


def _net():
    rx = tx = 0
    for line in (_read('/proc/net/dev', '') or '').splitlines()[2:]:
        name, _, rest = line.partition(':')
        if name.strip() in ('lo', ''):
            continue
        fields = rest.split()
        if len(fields) >= 9:
            rx += _int(fields[0])
            tx += _int(fields[8])
    return rx, tx


def disks():
    """Mounted local filesystems with real usage; network mounts are skipped."""
    result = []
    seen = set()
    for line in (_read('/proc/mounts', '') or '').splitlines():
        parts = line.split()
        if len(parts) < 3:
            continue
        device, mount, fstype = parts[0], parts[1].replace('\\040', ' '), parts[2]
        if fstype not in ('ext4', 'ext3', 'btrfs', 'xfs', 'vfat', 'exfat', 'ntfs3', 'f2fs'):
            continue
        if mount in seen:
            continue
        seen.add(mount)
        try:
            usage = shutil.disk_usage(mount)
        except OSError:
            continue
        if usage.total == 0:
            continue
        result.append({
            'mount': mount,
            'device': device,
            'fstype': fstype,
            'total': usage.total,
            'used': usage.used,
            'free': usage.free,
            'percent': round(usage.used * 100.0 / usage.total, 1),
        })
    if not result:
        usage = shutil.disk_usage('/')
        result.append({'mount': '/', 'device': '?', 'fstype': '?', 'total': usage.total,
                       'used': usage.used, 'free': usage.free,
                       'percent': round(usage.used * 100.0 / usage.total, 1)})
    return result


def battery():
    for base in sorted(glob.glob('/sys/class/power_supply/BAT*')):
        cap = _read(base + '/capacity')
        status = (_read(base + '/status') or '').strip()
        if cap is None:
            continue
        return {'capacity': _int(cap), 'status': status or None,
                'name': os.path.basename(base)}
    return None


def temperatures():
    """Returns a list of (label, celsius). Empty when no hwmon sensor."""
    readings = []
    for path in sorted(glob.glob('/sys/class/hwmon/hwmon*/temp*_input')):
        value = _read(path)
        if value is None:
            continue
        try:
            celsius = _int(value.strip()) / 1000.0
        except ValueError:
            continue
        if not (0 < celsius < 130):
            continue
        label = _read(os.path.join(os.path.dirname(path), 'name')) or 'sensor'
        readings.append((label.strip(), round(celsius, 1)))
    return readings


def kernel():
    parts = (_read('/proc/version', '') or '').split()
    return parts[2] if len(parts) > 2 else None


def distro():
    for line in (_read('/etc/os-release', '') or '').splitlines():
        if line.startswith('PRETTY_NAME='):
            return line.split('=', 1)[1].strip().strip('"')
    return None


def boot_time():
    """Startup duration reported by systemd, when it is available."""
    try:
        out = subprocess.run(['systemd-analyze'], capture_output=True, text=True, timeout=5)
    except (OSError, subprocess.SubprocessError):
        return None
    if out.returncode != 0 or 'Startup finished' not in out.stdout:
        return None
    text = out.stdout.strip().splitlines()[0]
    return text.replace('Startup finished in', '').strip()


def failed_units():
    try:
        out = subprocess.run(['systemctl', '--failed', '--no-legend', '--plain'],
                             capture_output=True, text=True, timeout=5)
    except (OSError, subprocess.SubprocessError):
        return None
    if out.returncode != 0:
        return None
    units = []
    for line in out.stdout.splitlines():
        parts = line.split()
        if len(parts) >= 2 and parts[0].endswith('.service'):
            units.append(parts[0])
    return units


def status_of(pid):
    try:
        return pathlib.Path('/proc/%d/status' % pid).read_text()
    except OSError:
        return ''


def process_name(pid):
    comm = _read('/proc/%d/comm' % pid)
    if comm:
        return comm.strip()
    cmdline = (_read('/proc/%d/cmdline' % pid) or '').split('\0')
    return os.path.basename(cmdline[0]) if cmdline and cmdline[0] else '?'


def process_ticks(pid):
    raw = _read('/proc/%d/stat' % pid)
    if not raw:
        return None
    try:
        tail = raw[raw.rindex(')') + 2:].split()
        return _int(tail[11]) + _int(tail[12])
    except (ValueError, IndexError):
        return None


def process_rss(pid):
    for line in status_of(pid).splitlines():
        if line.startswith('VmRSS:'):
            return _int(line.split()[1]) * 1024
    return 0


class Sampler:
    """Keeps the previous snapshot so percentages are real deltas."""

    def __init__(self):
        self.total, self.idle = cpu_times()
        self.cores = per_core_times()
        self.rx, self.tx = _net()
        self.stamp = time.monotonic()
        self._procs = {}

    def sample(self):
        now = time.monotonic()
        elapsed = max(now - self.stamp, 0.001)
        total, idle = cpu_times()
        d_total = max(total - self.total, 1)
        d_idle = max(idle - self.idle, 0)
        cpu = round((d_total - d_idle) * 100.0 / d_total, 1)

        cores = []
        for (c_total, c_idle), (p_total, p_idle) in zip(per_core_times(), self.cores):
            dc = max(c_total - p_total, 1)
            cores.append(round((dc - max(c_idle - p_idle, 0)) * 100.0 / dc, 1))
        rx, tx = _net()
        net = {'rx_kbs': round((rx - self.rx) / elapsed / 1024.0, 1),
               'tx_kbs': round((tx - self.tx) / elapsed / 1024.0, 1)}

        current = {}
        procs = []
        for entry in pathlib.Path('/proc').iterdir():
            if not entry.name.isdigit():
                continue
            pid = int(entry.name)
            ticks = process_ticks(pid)
            if ticks is None:
                continue
            current[pid] = ticks
            previous = self._procs.get(pid)
            share = 0.0
            if previous is not None:
                share = (ticks - previous) * 100.0 / (elapsed * CLK_TCK * cpu_count())
            procs.append({'pid': pid, 'name': process_name(pid),
                          'cpu': round(max(share, 0.0), 1), 'rss': process_rss(pid)})

        self.total, self.idle, self.cores = total, idle, per_core_times()
        self.rx, self.tx, self.stamp = rx, tx, now
        self._procs = current
        return {
            'cpu': cpu,
            'cores': cores,
            'net': net,
            'mem': meminfo(),
            'load': loadavg(),
            'processes': procs,
            'stamp': now,
        }


def settings_path():
    return pathlib.Path.home() / '.config/lumen/settings.json'


def read_settings():
    try:
        return json.loads(settings_path().read_text())
    except (OSError, ValueError):
        return {}


def write_settings(data):
    path = settings_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix('.json.tmp')
    temp.write_text(json.dumps(data, indent=2, sort_keys=True))
    temp.replace(path)


def animations_mode():
    """full / reduced / off, following the user's own preference file."""
    mode = str(read_settings().get('animations', 'full'))
    return mode if mode in ('full', 'reduced', 'off') else 'full'


def human_bytes(value):
    if value is None:
        return '—'
    step = 1024.0
    for unit in ('o', 'Ko', 'Mo', 'Go', 'To'):
        if abs(value) < step or unit == 'To':
            return ('%.1f %s' % (value, unit)) if unit != 'o' else ('%d o' % value)
        value /= step
    return '—'
