"""Nettoyage minimal du fichier de la barre XFCE.

Symptome vise : au demarrage, « Le greffon « (null) » n'a pas ete charge ».
Cause : un identifiant reste dans `plugin-ids` alors que sa definition a
disparu (c'est ce qui arrive quand un bouton est retire a moitie). On retire
uniquement ces identifiants morts et l'ancien bouton d'alimentation (12).
Aucun plugin qui fonctionne n'est touche : si le fichier est sain, il n'est
meme pas reecrit.
"""
import pathlib
import xml.etree.ElementTree as ET

PANEL_XML = '.config/xfce4/xfconf/xfce-perchannel-xml/xfce4-panel.xml'
DEAD_IDS = {12}


def clean(home):
    """Retourne (modifie, identifiants_retires). Ne leve jamais d'exception."""
    path = pathlib.Path(home) / PANEL_XML
    if not path.is_file():
        return False, []
    try:
        tree = ET.parse(str(path))
    except (ET.ParseError, OSError):
        return False, []
    root = tree.getroot()

    defined = set()
    dead_definitions = []
    for parent in root.iter():
        for prop in list(parent):
            name = prop.get('name') or ''
            if name.startswith('plugin-') and name[7:].isdigit():
                if name[7:] in {str(x) for x in DEAD_IDS}:
                    dead_definitions.append((parent, prop))
                else:
                    defined.add(name[7:])

    removed = []
    for parent, prop in dead_definitions:
        parent.remove(prop)
        removed.append(str(prop.get('name')).split('-', 1)[1])
        defined.discard(str(prop.get('name')).split('-', 1)[1])

    for prop in root.iter('property'):
        if prop.get('name') != 'plugin-ids':
            continue
        for value in list(prop.findall('value')):
            pid = (value.get('value') or '').strip()
            if pid not in defined:
                prop.remove(value)
                if pid not in removed:
                    removed.append(pid)

    if not removed:
        return False, []
    tree.write(str(path), encoding='utf-8', xml_declaration=False)
    return True, removed
